from flask import Flask, render_template, request, session
from generator import generate_question
from validator import check_answer

app = Flask(__name__)
app.secret_key = "math-question-generator-secret-key"


@app.route("/", methods=["GET", "POST"])
def index():
    feedback = ""
    explanation = ""

    selected_topic = session.get("selected_topic", "numerical_systems")
    selected_difficulty = session.get("selected_difficulty", "easy")

    if request.method == "POST":
        selected_topic = request.form.get("topic", selected_topic)
        selected_difficulty = request.form.get("difficulty", selected_difficulty)

        session["selected_topic"] = selected_topic
        session["selected_difficulty"] = selected_difficulty

        if "generate" in request.form:
            data = generate_question(selected_topic, selected_difficulty)

            session["question"] = data["question"]
            session["answer"] = data["answer"]
            session["explanation"] = data["explanation"]
            session["variables"] = data.get("variables", [])

        elif "submit" in request.form:
            correct_answer = session.get("answer")
            explanation = session.get("explanation", "")
            variables = session.get("variables", [])

            if correct_answer is None:
                feedback = "Please generate a question first."

            elif variables:
                all_correct = True

                for variable in variables:
                    user_value = request.form.get(variable, "")
                    correct_value = correct_answer.get(variable)

                    if not check_answer(user_value, correct_value):
                        all_correct = False

                if all_correct:
                    feedback = "Correct! Well done."
                else:
                    correct_parts = [
                        f"{variable} = {correct_answer[variable]}"
                        for variable in variables
                    ]
                    feedback = "Incorrect. The correct answer is " + ", ".join(correct_parts) + "."

            else:
                user_answer = request.form.get("answer", "")

                if check_answer(user_answer, correct_answer):
                    feedback = "Correct! Well done."
                else:
                    feedback = f"Incorrect. The correct answer is {correct_answer}."

    return render_template(
        "index.html",
        question=session.get("question"),
        feedback=feedback,
        explanation=explanation,
        variables=session.get("variables", []),
        selected_topic=selected_topic,
        selected_difficulty=selected_difficulty
    )


if __name__ == "__main__":
    app.run(debug=True)