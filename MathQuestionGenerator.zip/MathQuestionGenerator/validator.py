from fractions import Fraction


def normalise_text(value):
    return str(value).strip().lower().replace(" ", "")


def try_number(value):
    try:
        return float(Fraction(str(value).strip()))
    except Exception:
        try:
            return float(value)
        except Exception:
            return None


def check_answer(user_answer, correct_answer):
    user_num = try_number(user_answer)
    correct_num = try_number(correct_answer)

    if user_num is not None and correct_num is not None:
        return abs(user_num - correct_num) < 0.01

    return normalise_text(user_answer) == normalise_text(correct_answer)