import random
from fractions import Fraction


def generate_question(topic, difficulty):
    if topic == "numerical_systems":
        return generate_number_systems(difficulty)

    if topic == "propositional_logic":
        return generate_logic(difficulty)

    if topic == "linear_equations":
        return generate_linear_equations(difficulty)

    if topic == "probability":
        return generate_probability(difficulty)

    return generate_number_systems(difficulty)



def generate_number_systems(difficulty):
    question_type = random.choice(["type_1", "type_2"])

    if difficulty == "easy":
        if question_type == "type_1":
            decimal = random.randint(1, 31)
            binary = bin(decimal)[2:]

            return {
                "question": f"Convert the binary number {binary}₂ to decimal.",
                "answer": str(decimal),
                "explanation": explain_binary_to_decimal(binary, decimal)
            }

        decimal = random.randint(1, 300)
        binary = bin(decimal)[2:]

        return {
            "question": f"Convert the decimal number {decimal} to binary.",
            "answer": binary,
            "explanation": explain_decimal_to_binary(decimal, binary)
        }

    if difficulty == "medium":
        if question_type == "type_1":
            decimal = random.randint(1, 9999)
            binary = bin(decimal)[2:]
            hexadecimal = hex(decimal)[2:].upper()

            return {
                "question": f"Convert the binary number {binary}₂ to hexadecimal.",
                "answer": hexadecimal,
                "explanation": explain_binary_to_hex(binary, hexadecimal)
            }

        decimal = random.randint(1, 9999)
        hexadecimal = hex(decimal)[2:].upper()

        return {
            "question": f"Convert the hexadecimal number {hexadecimal}₁₆ to decimal.",
            "answer": str(decimal),
            "explanation": explain_hex_to_decimal(hexadecimal, decimal)
        }

    if difficulty == "hard":
        if question_type == "type_1":
            integer_part = 0 if random.random() < 0.8 else random.randint(1, 20)
            fraction_length = random.randint(3, 8)
            fraction_bits = "".join(random.choice(["0", "1"]) for _ in range(fraction_length))

            if "1" not in fraction_bits:
                fraction_bits = fraction_bits[:-1] + "1"

            binary_fraction = f"{bin(integer_part)[2:]}.{fraction_bits}"
            decimal_answer = binary_fraction_to_decimal(binary_fraction)

            return {
                "question": f"Convert the binary fraction {binary_fraction}₂ to decimal.",
                "answer": str(round(decimal_answer, 6)),
                "explanation": explain_binary_fraction_to_decimal(binary_fraction, decimal_answer)
            }

        decimal_fraction = round(random.uniform(0.1, 400.99), 3)
        binary_answer = decimal_fraction_to_binary(decimal_fraction)

        return {
            "question": f"Convert the decimal fraction {decimal_fraction} to binary.",
            "answer": binary_answer,
            "explanation": explain_decimal_fraction_to_binary(decimal_fraction, binary_answer)
        }


def explain_binary_to_decimal(binary, decimal):
    terms = []
    calculated_terms = []
    values = []
    power = len(binary) - 1

    for digit in binary:
        terms.append(f"({digit} × 2^{power})")
        calculated_terms.append(f"({digit} × {2 ** power})")
        if digit == "1":
            values.append(str(2 ** power))
        power -= 1

    return (
        f"{binary}₂ = {' + '.join(terms)}\n"
        f"= {' + '.join(calculated_terms)}\n"
        f"= {' + '.join(values)}\n"
        f"= {decimal}\n\n"
        f"Therefore, {binary}₂ = {decimal}."
    )


def explain_decimal_to_binary(decimal, binary):
    n = decimal
    steps = []

    while n > 1:
        quotient = n // 2
        remainder = n % 2
        steps.append(f"{n} ÷ 2 = {quotient} remainder {remainder}")
        n = quotient

    return (
        "\n".join(steps) +
        "\n\nRead the remainders from bottom to top.\n"
        f"Therefore, {decimal} = {binary}₂."
    )


def explain_binary_to_hex(binary, hexadecimal):
    padded = binary.zfill(((len(binary) + 3) // 4) * 4)
    groups = [padded[i:i + 4] for i in range(0, len(padded), 4)]
    hex_digits = [hex(int(group, 2))[2:].upper() for group in groups]

    return (
        "Split the binary number into blocks of four bits:\n"
        f"{' '.join(groups)}\n\n"
        "Convert each group to hexadecimal:\n"
        f"{' '.join(hex_digits)}\n\n"
        f"Therefore, {binary}₂ = {hexadecimal}₁₆."
    )


def explain_hex_to_decimal(hexadecimal, decimal):
    terms = []
    calculated_terms = []
    values = []
    power = len(hexadecimal) - 1

    for digit in hexadecimal:
        value = int(digit, 16)
        terms.append(f"({value} × 16^{power})")
        calculated_terms.append(f"({value} × {16 ** power})")
        values.append(str(value * (16 ** power)))
        power -= 1

    return (
        f"{hexadecimal}₁₆ = {' + '.join(terms)}\n"
        f"= {' + '.join(calculated_terms)}\n"
        f"= {' + '.join(values)}\n"
        f"= {decimal}\n\n"
        f"Therefore, {hexadecimal}₁₆ = {decimal}."
    )


def binary_fraction_to_decimal(binary_fraction):
    integer_part, fractional_part = binary_fraction.split(".")
    total = int(integer_part, 2)

    for i, bit in enumerate(fractional_part, start=1):
        if bit == "1":
            total += 2 ** (-i)

    return total


def explain_binary_fraction_to_decimal(binary_fraction, result):
    integer_part, fractional_part = binary_fraction.split(".")
    integer_decimal = int(integer_part, 2)

    terms = []
    values = []

    for i, bit in enumerate(fractional_part, start=1):
        terms.append(f"({bit} × 2^-{i})")
        if bit == "1":
            values.append(str(2 ** (-i)))

    value_str = " + ".join(values) if values else "0"

    return (
        f"Integer part:\n"
        f"{integer_part}₂ = {integer_decimal}\n\n"
        f"Fractional part:\n"
        f"{' + '.join(terms)}\n"
        f"= {value_str}\n\n"
        f"Total:\n"
        f"{binary_fraction}₂ = {round(result, 6)}"
    )


def decimal_fraction_to_binary(decimal_number, max_places=10):
    integer_part = int(decimal_number)
    fractional_part = decimal_number - integer_part
    integer_binary = bin(integer_part)[2:]
    bits = []

    for _ in range(max_places):
        fractional_part *= 2
        bit = int(fractional_part)
        bits.append(str(bit))
        fractional_part -= bit

        if fractional_part == 0:
            break

    return f"{integer_binary}.{''.join(bits)}"


def explain_decimal_fraction_to_binary(decimal_number, binary):
    integer_part = int(decimal_number)
    fractional_part = decimal_number - integer_part
    steps = []

    for _ in range(10):
        doubled = fractional_part * 2
        bit = int(doubled)
        remainder = round(doubled - bit, 6)
        steps.append(f"{round(fractional_part, 6)} × 2 = {bit} + {remainder}")
        fractional_part = remainder

        if fractional_part == 0:
            break

    return (
        f"Integer part:\n"
        f"{integer_part} = {bin(integer_part)[2:]}₂\n\n"
        f"Fractional conversion:\n"
        + "\n".join(steps) +
        "\n\nTherefore:\n"
        f"{decimal_number} ≈ {binary}₂"
    )

import random


def imp(a, b):
    return (not a) or b

import random

def generate_logic(difficulty):
    p = random.choice([True, False])
    q = random.choice([True, False])
    r = random.choice([True, False])

    if difficulty == "easy":
        template = random.choice([
            "p_and_not_q",
            "p_implies_q_and_r",
            "p_implies_q_or_p_implies_not_q",
            "p_implies_q_and_not_q"
        ])

        if template == "p_and_not_q":
            answer = p and not q
            return {
                "question": f"Evaluate p ∧ ¬q where p = {p} and q = {q}.",
                "answer": str(answer),
                "explanation": (
                    f"Step 1: Substitute the given values into the expression:\n"
                    f"{p} ∧ ¬({q})\n\n"
                    f"Step 2: Evaluate the negation (¬).\n"
                    f"The negation of {q} is {not q}.\n"
                    f"Expression becomes: {p} ∧ {not q}\n\n"
                    f"Step 3: Evaluate the conjunction (∧).\n"
                    f"A conjunction is True only if both sides are True[cite: 1021].\n"
                    f"{p} ∧ {not q} = {answer}\n\n"
                    f"Therefore, the final answer is {answer}."
                )
            }

        if template == "p_implies_q_and_r":
            q_and_r = q and r
            answer = (not p) or q_and_r
            return {
                "question": f"Evaluate p ⇒ (q ∧ r) where p = {p}, q = {q}, and r = {r}.",
                "answer": str(answer),
                "explanation": (
                    f"Step 1: Substitute the values:\n"
                    f"{p} ⇒ ({q} ∧ {r})\n\n"
                    f"Step 2: Evaluate the conjunction (∧) inside the parentheses.\n"
                    f"A conjunction is True only if both sides are True[cite: 1021].\n"
                    f"{q} ∧ {r} = {q_and_r}\n\n"
                    f"Step 3: Evaluate the implication (⇒).\n"
                    f"An implication is False only when the first part is True and the second part is False[cite: 1029].\n"
                    f"{p} ⇒ {q_and_r} = {answer}\n\n"
                    f"Therefore, the final answer is {answer}."
                )
            }

        if template == "p_implies_q_or_p_implies_not_q":
            not_q = not q
            p_implies_q = (not p) or q
            p_implies_not_q = (not p) or not_q
            answer = p_implies_q or p_implies_not_q
            return {
                "question": f"Evaluate (p ⇒ q) ∨ (p ⇒ ¬q) where p = {p} and q = {q}.",
                "answer": str(answer),
                "explanation": (
                    f"Step 1: Substitute the values:\n"
                    f"({p} ⇒ {q}) ∨ ({p} ⇒ ¬{q})\n\n"
                    f"Step 2: Evaluate ¬q:\n"
                    f"¬{q} = {not_q}\n\n"
                    f"Step 3: Evaluate the implications (⇒).\n"
                    f"An implication is False only when the first part is True and the second part is False[cite: 1029].\n"
                    f"Left side: {p} ⇒ {q} = {p_implies_q}\n"
                    f"Right side: {p} ⇒ {not_q} = {p_implies_not_q}\n\n"
                    f"Step 4: Evaluate the disjunction (∨).\n"
                    f"A disjunction is True if at least one side is True[cite: 1021].\n"
                    f"{p_implies_q} ∨ {p_implies_not_q} = {answer}\n\n"
                    f"Therefore, the final answer is {answer}."
                )
            }

        if template == "p_implies_q_and_not_q":
            not_q = not q
            q_and_not_q = q and not_q
            answer = (not p) or q_and_not_q
            return {
                "question": f"Evaluate p ⇒ (q ∧ ¬q) where p = {p} and q = {q}.",
                "answer": str(answer),
                "explanation": (
                    f"Step 1: Substitute the values:\n"
                    f"{p} ⇒ ({q} ∧ ¬{q})\n\n"
                    f"Step 2: Evaluate ¬q:\n"
                    f"¬{q} = {not_q}\n\n"
                    f"Step 3: Evaluate the conjunction (∧).\n"
                    f"({q} ∧ {not_q}) = {q_and_not_q} (Note: q ∧ ¬q is always a contradiction/False)[cite: 1008, 1009].\n\n"
                    f"Step 4: Evaluate the implication (⇒).\n"
                    f"{p} ⇒ {q_and_not_q} = {answer}\n\n"
                    f"Therefore, the final answer is {answer}."
                )
            }

    if difficulty == "medium":
        template = random.choice([
            "p_and_not_q_implies_r",
            "biconditional",
            "exclusive_or"
        ])

        if template == "p_and_not_q_implies_r":
            q_implies_r = (not q) or r
            not_q_implies_r = not q_implies_r
            answer = p and not_q_implies_r
            return {
                "question": f"Evaluate p ∧ ¬(q ⇒ r), where p = {p}, q = {q}, and r = {r}.",
                "answer": str(answer),
                "explanation": (
                    f"Step 1: Substitute the values:\n"
                    f"{p} ∧ ¬({q} ⇒ {r})\n\n"
                    f"Step 2: Evaluate the implication (⇒) in the parentheses.\n"
                    f"An implication is False only when the first part is True and the second part is False[cite: 1029].\n"
                    f"{q} ⇒ {r} = {q_implies_r}\n\n"
                    f"Step 3: Evaluate the negation (¬).\n"
                    f"¬({q_implies_r}) = {not_q_implies_r}\n\n"
                    f"Step 4: Evaluate the final conjunction (∧).\n"
                    f"{p} ∧ {not_q_implies_r} = {answer}\n\n"
                    f"Therefore, the final answer is {answer}."
                )
            }

        if template == "biconditional":
            answer = p == q
            return {
                "question": f"Evaluate p ⇔ q where p = {p} and q = {q}.",
                "answer": str(answer),
                "explanation": (
                    f"Step 1: Substitute the values:\n"
                    f"{p} ⇔ {q}\n\n"
                    f"Step 2: Evaluate the biconditional (⇔).\n"
                    f"A biconditional is True when both sides have the same truth value.\n"
                    f"Since p is {p} and q is {q}, they are {'the same' if answer else 'different'}.\n"
                    f"{p} ⇔ {q} = {answer}.\n\n"
                    f"Therefore, the final answer is {answer}."
                )
            }

        if template == "exclusive_or":
            p_or_q = p or q
            p_and_q = p and q
            answer = p_or_q and not p_and_q
            return {
                "question": f"Evaluate (p ∨ q) ∧ ¬(p ∧ q) where p = {p} and q = {q}.",
                "answer": str(answer),
                "explanation": (
                    f"Step 1: Substitute the values:\n"
                    f"({p} ∨ {q}) ∧ ¬({p} ∧ {q})\n\n"
                    f"Step 2: Evaluate the parentheses.\n"
                    f"p ∨ q: A disjunction is True if at least one side is True. {p} ∨ {q} = {p_or_q}[cite: 1021].\n"
                    f"p ∧ q: A conjunction is True if both sides are True. {p} ∧ {q} = {p_and_q}[cite: 1021].\n\n"
                    f"Step 3: Evaluate the negation (¬).\n"
                    f"¬({p_and_q}) = {not p_and_q}\n\n"
                    f"Step 4: Evaluate the final conjunction (∧).\n"
                    f"{p_or_q} ∧ {not p_and_q} = {answer}.\n\n"
                    f"Therefore, the final answer is {answer}."
                )
            }

    
    template = random.choice([
        "equivalence_one",
        "equivalence_two"
    ])

    if template == "equivalence_one":
        left = (not p) or (not q)
        right = not (p and q)
        answer = left == right
        return {
            "question": f"Check whether (p ⇒ ¬q) ⇔ ¬(p ∧ q) is true for p = {p} and q = {q}.",
            "answer": str(answer),
            "explanation": (
                f"Step 1: Evaluate the left side (p ⇒ ¬q).\n"
                f"Substitute values: {p} ⇒ ¬{q}\n"
                f"¬{q} = {not q}\n"
                f"{p} ⇒ {not q} = {left}\n\n"
                f"Step 2: Evaluate the right side ¬(p ∧ q).\n"
                f"{p} ∧ {q} = {p and q}\n"
                f"¬({p and q}) = {right}\n\n"
                f"Step 3: Compare both sides with the biconditional (⇔).\n"
                f"{left} ⇔ {right} = {answer}\n\n"
                f"Therefore, the statement evaluates to {answer}. Note that this is a demonstration of De Morgan's Law and conditional equivalence[cite: 1033]!"
            )
        }

    if template == "equivalence_two":
        q_implies_r = (not q) or r
        left = (not (p and q)) or r
        right = (not p) or q_implies_r
        answer = left == right
        return {
            "question": f"Check whether ((p ∧ q) ⇒ r) ⇔ (p ⇒ (q ⇒ r)) is true for p = {p}, q = {q}, and r = {r}.",
            "answer": str(answer),
            "explanation": (
                f"Step 1: Evaluate the left side ((p ∧ q) ⇒ r).\n"
                f"p ∧ q = {p and q}\n"
                f"{p and q} ⇒ {r} = {left}\n\n"
                f"Step 2: Evaluate the right side (p ⇒ (q ⇒ r)).\n"
                f"q ⇒ r = {q_implies_r}\n"
                f"{p} ⇒ {q_implies_r} = {right}\n\n"
                f"Step 3: Compare both sides with the biconditional (⇔).\n"
                f"{left} ⇔ {right} = {answer}\n\n"
                f"Therefore, the statement evaluates to {answer}. (This shows how implication distributes over conjunction!)"
            )
        }



def generate_linear_equations(difficulty):
    if difficulty == "easy":
        return generate_2_variable_system(
            coefficient_range=10,
            rhs_range=20,
            solution_range=8
        )

    if difficulty == "medium":
        return generate_2_variable_system(
            coefficient_range=19,
            rhs_range=50,
            solution_range=10
        )

    return generate_3_variable_system(
        coefficient_range=40,
        rhs_range=50,
        solution_range=5
    )




def generate_2_variable_system(coefficient_range, rhs_range, solution_range):
    while True:
        x = random.randint(-solution_range, solution_range)
        y = random.randint(-solution_range, solution_range)

        a1 = random.randint(1, coefficient_range)
        b1 = random.randint(1, coefficient_range)
        a2 = random.randint(1, coefficient_range)
        b2 = random.randint(1, coefficient_range)

        determinant = a1 * b2 - a2 * b1
        if determinant == 0:
            continue

        c1 = a1 * x + b1 * y
        c2 = a2 * x + b2 * y

        if not (1 <= abs(c1) <= rhs_range and 1 <= abs(c2) <= rhs_range):
            continue

        eq1 = format_equation_2(a1, b1, c1)
        eq2 = format_equation_2(a2, b2, c2)

        equations = [eq1, eq2]
        random.shuffle(equations)

        return {
            "question": (
                "Solve the system:\n"
                f"{equations[0]}\n"
                f"{equations[1]}"
            ),
            "answer": {"x": x, "y": y},
            "variables": ["x", "y"],
            "explanation": explain_2_variable_system(a1, b1, c1, a2, b2, c2, x, y)
        }


def explain_2_variable_system(a1, b1, c1, a2, b2, c2, x, y):
   
    new_b2 = a1 * b2 - a2 * b1
    new_c2 = a1 * c2 - a2 * c1

    return (
        "Solution. We solve the exercise using Gaussian elimination.\n\n"
        "We take the augmented matrix of the system and convert it into row echelon form:\n\n"
        f"[ {a1}  {b1} | {c1} ]\n"
        f"[ {a2}  {b2} | {c2} ]\n\n"
        f"Apply the row operation:\n"
        f"R2 ← {a1}R2 - {a2}R1\n\n"
        "This gives:\n"
        f"[ {a1}  {b1} | {c1} ]\n"
        f"[ 0  {new_b2} | {new_c2} ]\n\n"
        "Now convert back to equations and solve via backward substitution:\n\n"
        f"{format_equation_2(a1, b1, c1)}\n"
        f"{new_b2}y = {new_c2}\n\n"
        f"From the second equation:\n"
        f"y = {new_c2} ÷ {new_b2} = {y}\n\n"
        "Substitute into the first equation:\n"
        f"x = {x}\n\n"
        "From which we get the unique solution:\n"
        f"x = {x}\n"
        f"y = {y}"
    )


def generate_3_variable_system(coefficient_range, rhs_range, solution_range):
    while True:
        x = random.randint(-solution_range, solution_range)
        y = random.randint(-solution_range, solution_range)
        z = random.randint(-solution_range, solution_range)

        rows = []

        for _ in range(3):
            a = random.randint(1, coefficient_range)
            b = random.randint(1, coefficient_range)
            c = random.randint(1, coefficient_range)

            rhs = a * x + b * y + c * z

            if not (1 <= abs(rhs) <= rhs_range):
                break

            rows.append((a, b, c, rhs))

        if len(rows) != 3:
            continue

        eqs = [format_equation_3(*row) for row in rows]
        random.shuffle(eqs)

        return {
            "question": (
                "Solve the system:\n"
                f"{eqs[0]}\n{eqs[1]}\n{eqs[2]}"
            ),
            "answer": {"x": x, "y": y, "z": z},
            "variables": ["x", "y", "z"],
            "explanation": explain_3_variable_system(rows, x, y, z)
        }


def explain_3_variable_system(rows, x, y, z):
    r1, r2, r3 = rows
    a1, b1, c1, d1 = r1
    a2, b2, c2, d2 = r2
    a3, b3, c3, d3 = r3

    
    new_r2_b = a1 * b2 - a2 * b1
    new_r2_c = a1 * c2 - a2 * c1
    new_r2_d = a1 * d2 - a2 * d1

    new_r3_b = a1 * b3 - a3 * b1
    new_r3_c = a1 * c3 - a3 * c1
    new_r3_d = a1 * d3 - a3 * d1

    final_r3_c = new_r2_b * new_r3_c - new_r3_b * new_r2_c
    final_r3_d = new_r2_b * new_r3_d - new_r3_b * new_r2_d

    return (
        "Solution. We solve the exercise using Gaussian elimination.\n\n"
        "Write the initial augmented matrix:\n"
        f"[ {a1}  {b1}  {c1} | {d1} ]\n"
        f"[ {a2}  {b2}  {c2} | {d2} ]\n"
        f"[ {a3}  {b3}  {c3} | {d3} ]\n\n"
        
        "Step 1: Eliminate x from Row 2 and Row 3:\n"
        f"R2 ← {a1}*R2 - {a2}*R1\n"
        f"R3 ← {a1}*R3 - {a3}*R1\n\n"
        
        "This gives:\n"
        f"[ {a1}  {b1}  {c1} | {d1} ]\n"
        f"[ 0  {new_r2_b}  {new_r2_c} | {new_r2_d} ]\n"
        f"[ 0  {new_r3_b}  {new_r3_c} | {new_r3_d} ]\n\n"
        
        "Step 2: Eliminate y from Row 3:\n"
        f"R3 ← {new_r2_b}*R3 - ({new_r3_b})*R2\n\n"
        
        "This gives the row echelon form:\n"
        f"[ {a1}  {b1}  {c1} | {d1} ]\n"
        f"[ 0  {new_r2_b}  {new_r2_c} | {new_r2_d} ]\n"
        f"[ 0  0  {final_r3_c} | {final_r3_d} ]\n\n"
        
        "Step 3: Solve using backward substitution:\n"
        f"From Row 3: {final_r3_c}z = {final_r3_d}  ⇒  z = {z}\n"
        f"From Row 2: {new_r2_b}y + ({new_r2_c})({z}) = {new_r2_d}  ⇒  {new_r2_b}y = {new_r2_d - new_r2_c*z}  ⇒  y = {y}\n"
        f"From Row 1: {a1}x + ({b1})({y}) + ({c1})({z}) = {d1}  ⇒  {a1}x = {d1 - b1*y - c1*z}  ⇒  x = {x}\n\n"
        
        "From which we get the unique solution:\n"
        f"x = {x}, y = {y}, z = {z}"
    )


def format_equation_2(a, b, rhs):
    terms = []

    if random.choice([True, False]):
        terms.append(format_term(a, "x"))
        terms.append(format_term(b, "y"))
    else:
        terms.append(format_term(b, "y"))
        terms.append(format_term(a, "x"))

    return " + ".join(terms).replace("+ -", "- ") + f" = {rhs}"


def format_equation_3(a, b, c, rhs):
    terms = [
        format_term(a, "x"),
        format_term(b, "y"),
        format_term(c, "z")
    ]

    random.shuffle(terms)

    return " + ".join(terms).replace("+ -", "- ") + f" = {rhs}"


def format_term(coefficient, variable):
    if coefficient == 1:
        return variable
    return f"{coefficient}{variable}"


import random
from fractions import Fraction

def generate_probability(difficulty):
    if difficulty == "easy":
        animals = random.sample(["horses", "chickens", "dogs", "pigs", "cows", "sheep"], 3)
        colors = random.sample(["black", "white", "grey", "brown", "spotted"], 3)
        
        a1, a2, a3 = random.randint(2, 4), random.randint(3, 6), random.randint(1, 3)
        total = a1 + a2 + a3
        
        c1 = random.randint(2, total - 4)
        c2 = random.randint(1, total - c1 - 1)
        c3 = total - c1 - c2

        ans_a = Fraction(a1, total)
        ans_b = Fraction(total - c3, total)
        ans_c = Fraction(a1 + a2, total)

        question = (
            f"A small farm has {total} animals living on it. There are {a1} {animals[0]}, {a2} {animals[1]} and {a3} {animals[2]}.\n"
            f"Of these {total} animals, {c1} are coloured {colors[0]}, {c2} are coloured {colors[1]} and {c3} are coloured {colors[2]}.\n"
            f"One animal from the farm is selected at random. What is the probability that the animal is:\n"
            f"(a) A {animals[0][:-1]}?\n"
            f"(b) Not coloured {colors[2]}?\n"
            f"(c) A {animals[0][:-1]} or a {animals[1][:-1]}?"
        )

        
        return {
            "question": question,
            "answer": {"a": str(ans_a), "b": str(ans_b), "c": str(ans_c)},
            "variables": ["a", "b", "c"],
            "explanation": (
                f"(a) P({animals[0][:-1]}) = {a1}/{total} = {ans_a}\n\n"
                f"(b) P(Not {colors[2]}) = 1 - P({colors[2]}) = 1 - {c3}/{total} = {total-c3}/{total} = {ans_b}\n\n"
                f"(c) Since animals are mutually exclusive: P({animals[0][:-1]} ∪ {animals[1][:-1]}) = ({a1} + {a2})/{total} = {ans_c}"
            )
        }

    if difficulty == "medium":
        c1, c2, c3 = random.sample(["red", "blue", "green", "yellow", "black", "purple"], 3)
        count1 = random.randint(3, 5)
        count2 = random.randint(2, 4)
        count3 = random.randint(1, 3)
        total = count1 + count2 + count3

        ans_a = Fraction(count2, total) * Fraction(count1, total - 1) + Fraction(count1, total) * Fraction(count2, total - 1)
        ans_b = Fraction(total - count3, total) * Fraction(total - count3 - 1, total - 1)

        question = (
            f"A bag contains {total} coloured balls inside of it. There are {count1} {c1} balls, {count2} {c2} balls and {count3} {c3} ball(s).\n"
            f"A ball is selected from the bag at random, then, without replacement, a second ball is selected from the bag.\n"
            f"(a) Calculate the probability of selecting a {c2} and a {c1} ball in any order.\n"
            f"(b) Calculate the probability of not selecting the {c3} ball at all."
        )

        return {
            "question": question,
            "answer": {"a": str(ans_a), "b": str(ans_b)},
            "variables": ["a", "b"],
            "explanation": (
                f"(a) Two successful orders: ({c2} then {c1}) OR ({c1} then {c2}).\n"
                f"P({c2} then {c1}) = {count2}/{total} × {count1}/{total - 1} = {Fraction(count2, total) * Fraction(count1, total - 1)}\n"
                f"P({c1} then {c2}) = {count1}/{total} × {count2}/{total - 1} = {Fraction(count1, total) * Fraction(count2, total - 1)}\n"
                f"Sum = {ans_a}\n\n"
                f"(b) P(Not {c3}) = P(1st is not {c3}) × P(2nd is not {c3})\n"
                f"There are {total - count3} balls that are not {c3}.\n"
                f"P = {total - count3}/{total} × {total - count3 - 1}/{total - 1} = {ans_b}"
            )
        }

    if difficulty == "hard":
        trait = random.choice(["vegetarians", "left-handed", "bilingual", "members of a sports club"])
        
        pct_men = random.randint(2, 6) 
        pct_women = random.randint(7, 12) 
        
        ratio_w = random.randint(11, 15) 
        ratio_m = random.randint(8, 12)  
        total_ratio = ratio_w + ratio_m
        
        p_w = Fraction(ratio_w, total_ratio)
        p_m = Fraction(ratio_m, total_ratio)
        
        p_t_given_w = Fraction(pct_women, 100)
        p_t_given_m = Fraction(pct_men, 100)
        
        ans_a = (p_t_given_w * p_w) + (p_t_given_m * p_m)
        ans_b = (p_t_given_w * p_w) / ans_a

        question = (
            f"At a university, {pct_men}% of men are {trait} and {pct_women}% of women are {trait}.\n"
            f"The total student population is divided in the ratio {ratio_w}:{ratio_m} in favour of women.\n"
            f"(a) Calculate the probability that a randomly selected student from the university is {trait}.\n"
            f"(b) If a student is selected at random from among all {trait}, what is the probability the student is a woman?"
        )

        return {
            "question": question,
            "answer": {"a": str(ans_a), "b": str(ans_b)},
            "variables": ["a", "b"],
            "explanation": (
                f"Let W = Woman, M = Man, T = {trait.title()}.\n"
                f"P(W) = {ratio_w}/{total_ratio} = {p_w}\n"
                f"P(M) = {ratio_m}/{total_ratio} = {p_m}\n\n"
                f"(a) Using the Law of Total Probability:\n"
                f"P(T) = P(T|W)P(W) + P(T|M)P(M)\n"
                f"P(T) = ({pct_women}/100 × {p_w}) + ({pct_men}/100 × {p_m}) = {ans_a}\n\n"
                f"(b) Using Bayes' Theorem:\n"
                f"P(W|T) = [ P(T|W)P(W) ] / P(T)\n"
                f"P(W|T) = ({pct_women}/100 × {p_w}) / {ans_a} = {ans_b}"
            )
        }